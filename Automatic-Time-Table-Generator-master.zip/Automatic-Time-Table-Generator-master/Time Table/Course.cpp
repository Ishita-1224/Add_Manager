
#include "Course.h"

// Initializes course
Course::Course(int id, const string& name) : _id(id),
_name(name) { }

